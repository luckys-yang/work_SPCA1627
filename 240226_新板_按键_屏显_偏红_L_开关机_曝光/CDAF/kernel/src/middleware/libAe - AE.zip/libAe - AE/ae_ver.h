#ifndef _AAA_AE_VER_H__
#define _AAA_AE_VER_H__

#define AE_Version				10091501
/* v10030900 for D3
 *   
 * v10091501 		jg/lj
 * 1. calculate luma by MOE
 * 2. trigger AeProcess by Interript
 * 3. replace Ae Window by II Image;
 * 4. modify Ae Ready condition
 * 5. 
 */
#endif